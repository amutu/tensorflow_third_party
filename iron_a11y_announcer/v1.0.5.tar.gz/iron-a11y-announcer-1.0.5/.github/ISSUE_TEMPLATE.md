<!-- Instructions: https://github.com/PolymerElements/iron-a11y-announcer/CONTRIBUTING.md#filing-issues -->
### Description
<!-- Example: The `paper-foo` element causes the page to turn pink when clicked. -->

### Expected outcome

<!-- Example: The page stays the same color. -->

### Actual outcome

<!-- Example: The page turns pink. -->

### Live Demo
<!-- Example: https://jsbin.com/cagaye/edit?html,output -->

### Steps to reproduce

<!-- Example
1. Put a `paper-foo` element in the page.
2. Open the page in a web browser.
3. Click the `paper-foo` element.
-->

### Browsers Affected
<!-- Check all that apply -->
- [ ] Chrome
- [ ] Firefox
- [ ] Safari 9
- [ ] Safari 8
- [ ] Safari 7
- [ ] Edge
- [ ] IE 11
- [ ] IE 10
