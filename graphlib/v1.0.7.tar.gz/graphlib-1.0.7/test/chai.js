var chai = require("chai");

module.exports = chai;

chai.config.includeStack = true;
