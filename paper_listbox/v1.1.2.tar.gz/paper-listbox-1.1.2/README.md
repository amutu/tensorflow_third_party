# paper-listbox

![Build status](https://api.travis-ci.org/PolymerElements/paper-listbox.svg?branch=master)

`<paper-listbox>` implements an accessible listbox control with Material Design styling.
