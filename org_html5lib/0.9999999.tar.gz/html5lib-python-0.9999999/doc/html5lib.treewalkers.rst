treewalkers Package
===================

:mod:`treewalkers` Package
--------------------------

.. automodule:: html5lib.treewalkers
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`_base` Module
-------------------

.. automodule:: html5lib.treewalkers._base
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`dom` Module
-----------------

.. automodule:: html5lib.treewalkers.dom
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`etree` Module
-------------------

.. automodule:: html5lib.treewalkers.etree
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`genshistream` Module
--------------------------

.. automodule:: html5lib.treewalkers.genshistream
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`lxmletree` Module
-----------------------

.. automodule:: html5lib.treewalkers.lxmletree
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`pulldom` Module
---------------------

.. automodule:: html5lib.treewalkers.pulldom
    :members:
    :undoc-members:
    :show-inheritance:

