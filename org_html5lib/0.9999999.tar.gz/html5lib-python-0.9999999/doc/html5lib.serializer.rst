serializer Package
==================

:mod:`serializer` Package
-------------------------

.. automodule:: html5lib.serializer
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`htmlserializer` Module
----------------------------

.. automodule:: html5lib.serializer.htmlserializer
    :members:
    :undoc-members:
    :show-inheritance:

