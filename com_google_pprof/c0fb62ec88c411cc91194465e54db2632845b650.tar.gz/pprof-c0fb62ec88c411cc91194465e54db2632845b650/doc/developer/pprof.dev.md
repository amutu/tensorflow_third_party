This is pprof's developer documentation. It discusses how to maintain and extend
pprof. It has yet to be written.

# How is pprof code structured?

Internal vs external packages.

# External interface

## Plugins

## Legacy formats

#  Overview of internal packages
