# LIBXSMM Test Suite (INTERNAL)

This directory contains test cases which are exercising internals of LIBXSMM. This is not collection of code samples since the functionality used might be not part of the LIBXSMM API.

