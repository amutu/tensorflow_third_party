[This code's documentation lives on the grpc.io site.](http://www.grpc.io/docs/tutorials/basic/python.html)
